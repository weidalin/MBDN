python train.py --debug --gpu 4,5,6,7 --model resnet50 --batch_size 64 --display
